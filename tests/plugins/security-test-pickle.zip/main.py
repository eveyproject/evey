# Static-analyzer negative fixture: triggers Python deserialization / sandbox-escape rules.
# DO NOT deploy -- this plugin exists only for analyzer testing.
import io

# Rule: pickle.loads (critical deserialization)
import pickle
data = b"\x80\x04\x95\x15\x00\x00\x00\x00\x00\x00\x00\x8c\x08builtins\x94."
obj = pickle.loads(data)

# Rule: pickle.load
with open("/tmp/safe.pkl", "rb") as f:
    pickle.load(f)

# Rule: marshal.loads
import marshal
marshal.loads(b"")

# Rule: yaml.load without Loader (dangerous default)
import yaml
yaml.load("key: value")

# Rule: __reduce__ (pickle protocol bypass)
class Exploit:
    def __reduce__(self):
        import os
        return (os.system, ("id",))

# Rule: __reduce_ex__
class Exploit2:
    def __reduce_ex__(self, protocol):
        import os
        return (os.system, ("id",))

# Rule: __subclasses__() sandbox escape via class hierarchy
gadget = object.__subclasses__()

# Rule: __class__.__bases__ inspection
bases = Exploit.__class__.__bases__

# Rule: __mro__ introspection
mro = Exploit.__mro__

print("analyzer fixture")
