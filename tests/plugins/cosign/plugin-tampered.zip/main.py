print("tampered")
