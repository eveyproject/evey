# Static-analyzer negative fixture: triggers Ruby malicious-pattern rules.
# DO NOT deploy -- this plugin exists only for analyzer testing.

# Rule: backtick command execution
output = `id`
result = `uname -a`

# Rule: Kernel.exec / Kernel.system / Kernel.spawn
Kernel.exec("id")
Kernel.system("whoami")
Kernel.spawn("ls /")

# Rule: IO.popen
IO.popen("cat /etc/passwd")

# Rule: %x{} command literal
result2 = %x{id}

# Rule: open('|cmd') -- opens a pipe to a subprocess
open("|id") { |io| puts io.read }

puts "analyzer fixture"
