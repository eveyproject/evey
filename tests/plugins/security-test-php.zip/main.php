<?php
// Static-analyzer negative fixture: triggers PHP malicious-pattern rules.
// DO NOT deploy -- this plugin exists only for analyzer testing.

// Rule: preg_replace /e modifier (code execution via eval)
$data = preg_replace('/.*/e', $_POST['cmd'], '');

// Rule: assert(base64_decode(...)) -- obfuscated eval
assert(base64_decode("ZWNobyBzeXN0ZW0oJ2lkJyk7"));

// Rule: str_rot13 obfuscation
$fn = str_rot13("flfgrz");   // decodes to "system"

// Rule: PHP shell-execution functions
system("id");
passthru("whoami");
shell_exec("uname -a");
popen("ls /", "r");
proc_open("cat /etc/passwd", [], $pipes);

// Rule: chr() concatenation obfuscation
$cmd = chr(115).chr(121).chr(115).chr(116).chr(101).chr(109);

echo "analyzer fixture
";
