// Static-analyzer negative fixture: triggers Go unsafe.Pointer rules.
// DO NOT deploy -- this plugin exists only for analyzer testing.
package main

import (
	"fmt"
	"unsafe"
)

func main() {
	// Rule: unsafe.Pointer (warning)
	x := 42
	p := unsafe.Pointer(&x)
	_ = p

	// Rule: unsafe.Slice
	var b [4]byte
	s := unsafe.Slice(&b[0], 4)
	_ = s

	// Rule: unsafe.SliceData
	sd := unsafe.SliceData(s)
	_ = sd

	// Rule: unsafe.StringData
	str := "hello"
	strPtr := unsafe.StringData(str)
	_ = strPtr

	fmt.Println("analyzer fixture")
}
